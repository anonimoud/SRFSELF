USAGE
======
* termux
* python module os
* curl bash
* web dav
* CSRF (Cross Site Request Forgery) in curl

# SRSELF
<p>python2 prongram</p>
sever repeat mesenge self 😁

### chating in server privacy

<u>free for all</u>

INSTALLATION
==========
  ```
 pkg update && pkg upgrade;pkg install python;python main.py;
  ```
